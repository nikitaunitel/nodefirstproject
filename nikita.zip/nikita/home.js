// event emitter


var event=require('events');
var emitter= new event.EventEmitter();
emitter.on('bellicon',(dd)=>{
    console.log(`${dd} period ended`);
});
emitter.emit('bellicon','2nd');






// create html file

const fs= require('fs');
var newfilename= fs.writeFile('home.html','This is Homepage',()=>{
    console.log('File Generated');
});
var myfilename= fs.appendFile('home.html','This is My Homepage',()=>{
    console.log('File Regenerated');
});







// machine information tracking

const os= require('os');
console.log(os.cpus())





// Create new server


const http= require('http');

var server=http.createServer((req,res)=>{
    if(req.url=='/')
    {
        res.write('HomePage Running');
        res.end();
    }
    else if(req.url=='/about'){
        res.write('About Page Running');
        res.end();
    }

    else{
        res.write('Not Found');
        res.end();
    }
    
});

server.listen(4000);

console.log('Server Running on Port no 4000');


var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: ""
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  con.query("CREATE DATABASE nikitatestdb", function (err, result) {
    if (err) throw err;
    console.log("Database created");
  });
});


