// const _ = require('lodash');
// const people=require('./test/people.js');
// console.log(people.people);
// console.log(people.abc);
// people.exam();
// people.exam2();

// // console.log(_.last(people));
// console.log(_.last(people));

//display path

// const path= require('path');
// var mypath=path.extname('C:/Users/SEO/Desktop/nikita/index.js');
// console.log(mypath);


//os built in module

// const os= require('os');
// console.log(os.hostname());
// console.log(os.cpus());
// console.log(os.platform());
// console.log(os.userInfo());
// console.log(os.uptime());


// nodejs file system

// var http = require('http');
// var fs = require('fs');
// http.createServer(function (req, res) {
//   fs.readFile('demofile1.html', function(err, data) {
//     res.writeHead(200, {'Content-Type': 'text/html'});
//     res.write(data);
//     return res.end();
//   });
// }).listen(8080);



// Create file

// var fs= require('fs');
// fs.writeFile('home.html','My name is Nikita',()=>{console.log('Saved')})

// fs.appendFile('home.html','My name is Nikita B',()=>{console.log('Saved')})



//read file on http / localhost

// var http = require('http');
// var fs = require('fs');
// http.createServer(function (req, res) {
//   fs.readFile('home.html', function(err, data) {
//     res.writeHead(200, {'Content-Type': 'text/html'});
//     res.write(data);
//     return res.end();
//   });
// }).listen(8080);

// READ FILE IN CONSOLE LOG

// const { Console } = require('console');
// const fs= require('fs');
//////////// const data=fs.readFile('home.html');
// fs.readFile('home.html',(err,data)=>{console.log(data.toString())});


// EVENT EMITTER




// var events = require('events');
// var eventEmitter = new events.EventEmitter();

// // Create an event handler:

// eventEmitter.on('Bellicon', (text,tt)=>console.log(`Subsribed ${text} ${tt}`));

// // Fire the 'scream' event:
// eventEmitter.emit('Bellicon','My Channel','10.36');


// const http= require('http');
// const server= http.createServer((req,res)=>
// {
//     res.write('Hello my name is Nikita');
//     res.write('I am a Node.js developer');
//     res.end();
// });
// server.listen(3000);
// console.log('Listening on 3000');


//read data on server

// const http=require('http');
// const serv=http.createServer((req,res)=>{
//     if(req.url=='/')
//     {
//         res.write('I am Nikita Basak');
//         res.end();
//     }
//     else if(req.url=='/about')
//     {
//         res.write('This is About Page');
//         res.end();
//     }
//     else if(req.url=='/service')
//     {
//         res.write('This is Service Page');
//         res.end();
//     }
//     else{
//         res.write('Not Found');
//         res.end();
//     }
    
// });
// serv.listen(4000)
// console.log('Listening on 4000');

