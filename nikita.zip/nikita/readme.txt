---------------------------
Event emitter  Event module
---------------------------

In this core project we create an event . when event is occured then a massege passed through console log


const event=require('events'); //it use to require event module

var emitter= new event.EventEmitter(); // it use to create new emitter class. you can also modify var emitter class as abc dfh

emitter.on('bellicon',()=>{
    console.log('period ended'); //////when bellicon event occured then period ended msg showed in console log
})

emitter.emit('bellicon'); ///when an event raised . it means bellicon event raised then follow the above line msg

emitter.on('bellicon',(dd)=>{
    console.log(`${dd} period ended`);
});
emitter.emit('bellicon','2nd');// pass variable data

----------------------------
FS Module
----------------------------

Here we create a new html file 

step1 require fs module

const fs=require('fs');

step 2 writeFile 

var abc = fs.writeFile('home.html','This is Home page',()=>{
    console.log('Homepage Created');
})


----------------------------------------------------------------------------------------------------------
Mix of event and fs module
In this core project we create an event . when event is occured then a file crated with some text
----------------------------------------------------------------------------------------------------------

const event=require('events'); // require event module
const fs=require('fs'); // require fs module
var emitter=new event.EventEmitter(); // create new event class

// bellicon event create a bellicon.html file written with period started if err then throw err means where err occured

emitter.on('bellicon',()=>{
    fs.writeFile('bellicon.html','period started',(err)=>{
        //console.log('bellicon.html created');
        if(err) throw err;
    });
});

//when a bellicon event raised

emitter.emit('bellicon');
