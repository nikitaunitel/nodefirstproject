// const event=require('events');
// var emitter=new event.EventEmitter();

// emitter.on('bellicon',(dd)=>{
//     console.log(`${dd} Period ended`);
// })
// emitter.emit('bellicon','2nd');

// const fs= require('fs');
// var homepage= fs.writeFile('home.html','This is Homepage',()=>{
//     console.log('home.html created');
// })
// var homepage1=fs.appendFile('home.html','this is edited homepage',()=>{
//     console.log('Homepage edited');
// })

// const fs=require('fs');
// fs.unlink('home.html',(err)=>{
//     if(err) throw err 
//     ////console.log('Not Found');
//     else
//     console.log ('Founded And Unlinked');
// });

// const event=require('events');
// const fs=require('fs');
// var emitter=new event.EventEmitter();
// emitter.on('bellicon',()=>{
//     fs.writeFile('bellicon.html','period started',(err)=>{
//         //console.log('bellicon.html created');
//         if(err) throw err;
//     });
// });
// emitter.emit('bellicon');

// const http=require('http');

// var server=http.createServer((req,res)=>{
//     if(req.url=='/')
//     {
//         res.write('Homepage');
//         res.end();
//     }
//     else if(req.url=='/about');
//     {
//         res.write('AboutPage');
//         res.end();
//     }
// });

// server.listen(4000);
// console.log('server running on 4000');

const http=require('http');
var server=http.createServer((req,res)=>{
    if(req.url=='/')
    {
        res.write('Home');
        res.end();
    }
    else if(req.url=='/about')
    {
        res.write('about page');
        res.end()
    }
});
server.listen(4000);
console.log('running');