var people= ['ab','cd'];
var abc= ['abc','cde'];
function exam()
{
    console.log('My First name is Nikita');
}
function exam2()
{
    console.log('My Last name is Basak');
}

module.exports={people,abc,exam,exam2};
// module.exports=abc;